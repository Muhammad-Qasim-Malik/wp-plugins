<?php
/*
Plugin Name: Plugin Purchase Manager
Description: Handles plugin purchases, form submissions, email notifications, and admin page to manage submissions.
Version: 1.1
Author: Muhammad Qasim
*/

if (!defined('ABSPATH')) exit;

/*
|--------------------------------------------------------------------------
| 1. CREATE DATABASE TABLE (NO PREFIX)
|--------------------------------------------------------------------------
*/

function ppm_create_db_table() {
    global $wpdb;

    $table_name = 'plugin_purchases'; // no prefix
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        plugin_id BIGINT(20) NOT NULL,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        website VARCHAR(255) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'ppm_create_db_table');


/*
|--------------------------------------------------------------------------
| 2. SHORTCODE FOR FRONTEND FORM
|--------------------------------------------------------------------------
*/

function ppm_render_form() {

    if (!isset($_GET['plugin_purchased']) || intval($_GET['plugin_purchased']) !== 1) {
        wp_redirect(home_url());
        exit;
    }

    global $wpdb;
    $table_name = 'plugin_purchases';

    $plugin_id = isset($_GET['plugin_id']) ? intval($_GET['plugin_id']) : 0;
    $plugin_title = $plugin_id ? get_the_title($plugin_id) : '';

    $form_submitted = false;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ppm_submit'])) {

        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $website = esc_url_raw($_POST['website']);
        $plugin_id_hidden = intval($_POST['plugin_id']);

        $wpdb->insert(
            $table_name,
            [
                'plugin_id' => $plugin_id_hidden,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'email' => $email,
                'phone' => $phone,
                'website' => $website,
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s']
        );

        // Send email
        $plugin_title_hidden = $plugin_id_hidden ? get_the_title($plugin_id_hidden) : 'Unknown Plugin';
        $to = 'muhammadqasim5864@gmail.com';
        $subject = 'New Plugin Purchase Notification';
        $message = "Hello Admin,\n\nA new user purchased your plugin:\n\n";
        $message .= "Plugin: $plugin_title_hidden\n";
        $message .= "First Name: $first_name\n";
        $message .= "Last Name: $last_name\n";
        $message .= "Email: $email\n";
        $message .= "Phone: $phone\n";
        $message .= "Website: $website\n\n";
        $message .= "Please contact him to deploy the plugin.\n\nThanks.";

        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        wp_mail($to, $subject, $message, $headers);

        $form_submitted = true;
    }

    ob_start();
    ?>

    <div style="padding:20px; background:#f9f9f9; border:1px solid #ddd; margin-bottom:20px;">
        <strong>Thank you for purchasing!</strong><br>
        <?php if ($plugin_title) echo "Plugin: <strong>{$plugin_title}</strong>"; ?>
    </div>

    <?php if ($form_submitted): ?>

        <div style="padding:15px; background:#d7f1ff; border:1px solid #9cd3ff;">
            Thank you! Your details have been submitted.
        </div>

    <?php else: ?>

        <form method="post">
            <input type="hidden" name="plugin_id" value="<?php echo esc_attr($plugin_id); ?>">
            <input type="hidden" name="ppm_submit" value="1">

            <p><label>First Name:</label><br><input type="text" name="first_name" required></p>
            <p><label>Last Name:</label><br><input type="text" name="last_name" required></p>
            <p><label>Email:</label><br><input type="email" name="email" required></p>
            <p><label>Phone:</label><br><input type="text" name="phone" required></p>
            <p><label>Website URL:</label><br><input type="url" name="website" required></p>

            <button type="submit">Submit</button>
        </form>

    <?php endif;

    return ob_get_clean();
}
add_shortcode('plugin_purchase_form', 'ppm_render_form');


/*
|--------------------------------------------------------------------------
| 3. ADMIN MENU + LIST PAGE
|--------------------------------------------------------------------------
*/

function ppm_admin_menu() {
    add_menu_page(
        'Plugin Purchases',
        'Plugin Purchases',
        'manage_options',
        'plugin-purchases',
        'ppm_admin_page',
        'dashicons-feedback',
        30
    );
}
add_action('admin_menu', 'ppm_admin_menu');


function ppm_admin_page() {
    global $wpdb;
    $table_name = 'plugin_purchases';

    // Fetch rows
    $rows = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");

    ?>
    <div class="wrap">
        <h1>Plugin Purchases</h1>

        <!-- DataTables CSS -->
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

        <!-- jQuery (if not already loaded by WP admin) -->
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

        <!-- DataTables JS -->
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

        <script>
        jQuery(document).ready(function($) {
            $('#ppm-table').DataTable({
                "pageLength": 20,
                "order": [[0, "desc"]],
                "responsive": true
            });
        });
        </script>

        <table id="ppm-table" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Plugin</th>
                    <th>First</th>
                    <th>Last</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Website</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($rows): ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td><?php echo esc_html($r->id); ?></td>
                            <td><?php echo esc_html(get_the_title($r->plugin_id)); ?></td>
                            <td><?php echo esc_html($r->first_name); ?></td>
                            <td><?php echo esc_html($r->last_name); ?></td>
                            <td><?php echo esc_html($r->email); ?></td>
                            <td><?php echo esc_html($r->phone); ?></td>
                            <td><?php echo esc_html($r->website); ?></td>
                            <td><?php echo esc_html($r->created_at); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}
